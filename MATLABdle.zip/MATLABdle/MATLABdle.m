clc; %clear command window
close() %closes figures if there are any open

wordPool = readcell("MATLABdle_database.xlsx");

selection = menu('Play MATLABdle?','Yes','Heck yes');
while selection == 1 || selection == 2
    %Instructions
    fprintf('<strong>Instructions</strong>\n');
    fprintf('\t<strong>MATLABdle</strong> is a game where a user, like you, inputs a five-letter-word \n');
    fprintf('in attempt to guess a randomly selected MATLAB built-in function\n');
    fprintf('or coding term.\n\t After typing out the five-letter-word, press enter and a\n');
    fprintf("figure should appear (it may be hiding, so don't be afraid to alt-tab for it)\n");
    fprintf('\tIn the figure, a green box means that the letter is in the correct location. A\n');
    fprintf('yellow box means that the letter is somewhere in the word. Be careful as we do\n');
    fprintf('not disclose the number of duplicate letters in the guess (you may recieve a far\n');
    fprintf('more yellow boxes than number of letters in the actual solution. Lastly, a greyed\n');
    fprintf('out box means that the letter is not in the word at all. I hope you have fun!\n\n');
    fprintf('You may need to scroll up for the <strong>Instructions</strong>!\n\n')
    %initialize
    w_panels = makeBoxes();
    soundAccepted = audioread('MATLABdleAccepted.m4a');
    soundDeclined = audioread('MATLABdleDeclined.m4a');
    numGuesses = 0;
    wordGuessed = false;
    guess = '';
    validCharacters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    onlyLetters = true;

    %choose random word from database (wordPool)
    solutionNum = randi(height(wordPool));
    solution = wordPool(solutionNum);
    solution = char(solution); %convert to character string

    numLetters = length(solution);

    %start game
    disp('A word has been chosen');
    while wordGuessed == false && numGuesses ~= 6


        %obtaining user guess + validation
        while length(guess) ~= numLetters || ~onlyLetters
            onlyLetters = true;
            guess=input(['<strong>What is your guess? Please enter a </strong>' num2str(numLetters) ' <strong>letter word: </strong>'] ,"s");
            guess = upper(char(guess)); %convert guess to capitalized character string
            for i = 1:length(guess)
                if ~contains(validCharacters, guess(i))
                    onlyLetters = false;
                end
            end
            if length(guess) ~= numLetters || ~onlyLetters
                sound(soundDeclined);
            end
            if length(guess) ~= numLetters
                fprintf(2,'\tmake sure you are inputting a %i letter word\n', numLetters);
            end
            if ~onlyLetters
                fprintf(2,'\tmake sure you are only inputting letters. NO NUMBERS NOR SPECIAL CHARACTERS\n');
            end
        end

        numGuesses = numGuesses + 1;
        makeWord(solution,guess,w_panels(numGuesses,:));
        sound(soundAccepted);
        if guess == solution
            wordGuessed = true;
        end

        guess = '';
    end
    %results
    if wordGuessed == true
        fprintf('\nCongratulations!!!\n\tYou got the word, %s, in %i guesses!\n', solution, numGuesses);
    else
        fprintf('\nYou lost :c \n\tthe word was %s\n', solution);
    end

    selection = menu('Play MATLABdle again?','Yes','Heck yes', 'No');

    if selection == 1 || selection == 2
        close();
    end

end % end program



function word = makeWord(solution, guess, letterPanels) % letterPanels is an array of five panels, one for each letter of the 5 letter guess
GREEN = [.1 0.9 .3];
GREY = [0.5 0.5 0.5];
YELLOW = [0.95 0.85 0];

for i=1:5
    letterColor = [0 0 0];
    if guess(i) == solution(i)
        letterColor = GREEN;
    elseif contains(solution, guess(i))
        letterColor = YELLOW;
    else
        letterColor = GREY;
    end

    word(i) = uicontrol(letterPanels(i), 'style','text',...
        'units','norm',...
        'pos',[0 0 1 1],...
        'string',guess(i), "BackgroundColor", letterColor, 'ForegroundColor', 'white', 'FontSize', 25);
end
end

function w_panels = makeBoxes()
f = figure;

w_panels(1,1) = uipanel(f, 'Position', [0.0375 0.834 0.125 0.125]);
w_panels(1,2) = uipanel(f, 'Position', [0.2375 0.834 0.125 0.125]);
w_panels(1,3) = uipanel(f, 'Position', [0.4375 0.834 0.125 0.125]);
w_panels(1,4) = uipanel(f, 'Position', [0.6375 0.834 0.125 0.125]);
w_panels(1,5) = uipanel(f, 'Position', [0.8375 0.834 0.125 0.125]);

w_panels(2,1) = uipanel(f, 'Position', [0.0375 0.668 0.125 0.125]);
w_panels(2,2) = uipanel(f, 'Position', [0.2375 0.668 0.125 0.125]);
w_panels(2,3) = uipanel(f, 'Position', [0.4375 0.668 0.125 0.125]);
w_panels(2,4) = uipanel(f, 'Position', [0.6375 0.668 0.125 0.125]);
w_panels(2,5) = uipanel(f, 'Position', [0.8375 0.668 0.125 0.125]);

w_panels(3,1) = uipanel(f, 'Position', [0.0375 0.502 0.125 0.125]);
w_panels(3,2) = uipanel(f, 'Position', [0.2375 0.502 0.125 0.125]);
w_panels(3,3) = uipanel(f, 'Position', [0.4375 0.502 0.125 0.125]);
w_panels(3,4) = uipanel(f, 'Position', [0.6375 0.502 0.125 0.125]);
w_panels(3,5) = uipanel(f, 'Position', [0.8375 0.502 0.125 0.125]);

w_panels(4,1) = uipanel(f, 'Position', [0.0375 0.336 0.125 0.125]);
w_panels(4,2) = uipanel(f, 'Position', [0.2375 0.336 0.125 0.125]);
w_panels(4,3) = uipanel(f, 'Position', [0.4375 0.336 0.125 0.125]);
w_panels(4,4) = uipanel(f, 'Position', [0.6375 0.336 0.125 0.125]);
w_panels(4,5) = uipanel(f, 'Position', [0.8375 0.336 0.125 0.125]);

w_panels(5,1) = uipanel(f, 'Position', [0.0375 0.17 0.125 0.125]);
w_panels(5,2) = uipanel(f, 'Position', [0.2375 0.17 0.125 0.125]);
w_panels(5,3) = uipanel(f, 'Position', [0.4375 0.17 0.125 0.125]);
w_panels(5,4) = uipanel(f, 'Position', [0.6375 0.17 0.125 0.125]);
w_panels(5,5) = uipanel(f, 'Position', [0.8375 0.17 0.125 0.125]);

w_panels(6,1) = uipanel(f, 'Position', [0.0375 0.004 0.125 0.125]);
w_panels(6,2) = uipanel(f, 'Position', [0.2375 0.004 0.125 0.125]);
w_panels(6,3) = uipanel(f, 'Position', [0.4375 0.004 0.125 0.125]);
w_panels(6,4) = uipanel(f, 'Position', [0.6375 0.004 0.125 0.125]);
w_panels(6,5) = uipanel(f, 'Position', [0.8375 0.004 0.125 0.125]);

end